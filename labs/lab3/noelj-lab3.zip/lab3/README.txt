Part 0:

Renamed lab3.html to index.html so Apache finds and loads it.

Part 1:

Fairly simple (as a CS major), only difficulty was realizing body loads after head and so I moved my script from <head> to the end of <body> so the DOM had loaded properly before iterating.

Part 2:

Is the better way to do this the .each() method with jQuery?

Part 3:

Background coloring was easy, moving the element to the right took some research... had to set the position to relative before it would shift right.

The quote is from the Merchant of Venice, Shakespeare. Also happens to be the quote inscribed on the Tute screw.