For number 7 I assumed you wanted separate queries per bullet.

For number 8 I assumed you didn't want unique names.

-Joe