Joseph Noel (noelj)

Part 1:
Used essentially the same format as my XML from lab2, validated on JSONlint.

Part 2:
After opening my lab 2 on my laptop, realized it looks horrible (looked better on my desktop).
So I fixed the formatting to look better.
